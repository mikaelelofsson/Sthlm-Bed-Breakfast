
angular.module('starter', ['ionic'])


  .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

    //$ionicConfigProvider.tabs.position('bottom') gör så att appens tabs hamnar längst ner på skärmen. 
    //Det sker automatiskt på en IOS-enhet men inte på en ANDROID-enhet.
    $ionicConfigProvider.tabs.position('bottom');

    //Här anges appens olika "states", det vill säga olika vyer som appen kommer att gå igenom. 
    //Här beskrivs även hur de olika "states" är beroende av varandra. 
    //Här anges även vilken controller som vyerna ska inneha, samt adress till html-fil. 
    $stateProvider
      .state('tabs', {
        url: '/tabs',
        abstract: true,
        templateUrl: 'templates/tabs.html'
      })
      .state('tabs.steg1', {
        url: '/steg1',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/steg1.html',
            controller: 'ListController'
          }
        }
      })

      .state('tabs.steg2', {
        url: '/steg2',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/steg2.html',
            controller: 'ListController'
          }
        }
      })

      .state('tabs.steg3', {
        url: '/steg3',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/steg3.html',
            controller: 'ListController'
          }
        }
      })

      .state('tabs.steg4', {
        url: '/steg4',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/steg4.html',
            controller: 'ListController'
          }
        }
      })
      .state('tabs.steg5', {
        url: '/steg5',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/steg5.html',
            controller: 'ListController'
          }
        }
      })

      .state('tabs.home', {
        url: '/home',
        views: {
          'home-tab': {
            templateUrl: 'templates/home.html'
          }
        }
      })

      .state('tabs.details', {
        url: '/steg2/:roomId',
        parent: 'tabs',
        views: {
          'booking-tab': {
            templateUrl: 'templates/details.html',
            controller: 'ListController'
          }
        }
      })

    //Här anges vilken vy som appen ska starta ifrån.
    $urlRouterProvider.otherwise('/tabs/home');

  })



  //I .run(function($rootScope){}  beskriver jag alla de variabler och funktioner som ska kunna nås
  //av samtliga "states" oavsett vilken controller de innehar. Detta är viktigt eftersom
  //varje ny "state" erhåller en egen instans av ListController.
  .run(function ($rootScope) {


    $rootScope.user = {
      firstName: '',
      lastName: '',
      phone: '',
      email: '',
      checkOutDate: '',
      nrOfAdults: '',
      nrOfChildren: '',
      room: '',
      shortName: '',
      price: '',
      firstDate: new Date(),

      setRoomInfo: function (roomInput,
        priceInput,
        shortnameInput) {
        this.room = roomInput;
        this.price = priceInput;
        this.shortName = shortnameInput;

      }
    }

  })


  //I ListController angerar jag alla de variabler och funktioner som jag vill
  //ska vara tillgängliga för alla mina undersidor (som använder Listcontroller). 
  //Varje ny sida får en ny instans av denna controller, således kan man inte 
  //spara data i en variabel i controllern på en sida och återfå denna data på en annan sida,
  // trots att båda använder ListController.
  .controller('ListController', function ($scope, $http, $state, $rootScope) {

    $scope.myFunctions = {

      //buttonClicked anger om knappen i ett formulär har blivit nedtryck eller inte.
      buttonClicked: false,

      //buttonLink innehåller en sträng med den länk man vill tilldela knappen i ett formulär. 
      buttonLink: '',

      //Felmeddelande-text i formuläret som blir initierat med en meddelandetext, om användare har matat in felaktiga uppgifter.
      errorText: '',


      //Följande funktion anropas när användaren klickar på knappen. 
      checkInputs: function (view) {
        this.buttonClicked = true;

        //Om användaren befinner sig på steg 1 (view==1) och variablerna som anges har fått ett värde så tilldelas variabeln buttonLink ett värde.
        if (view == 1 && $rootScope.user.checkInDate && $rootScope.user.checkOutDate && $rootScope.user.nrOfAdults && ($rootScope.user.nrOfChildren || $rootScope.user.nrOfChildren == '')) {
          this.buttonLink = "#/tabs/steg2";

        }
        //Samma som ovan men om användaren är på steg 3.
        else if (view == 3 && $rootScope.user.firstName && $rootScope.user.lastName && $rootScope.user.phone && $rootScope.user.email && isNaN($rootScope.user.firstName) && isNaN($rootScope.user.lastName)) {
          this.buttonLink = "#/tabs/steg4";
        }
        else {
          //Om användaren har matat in felaktiga uppgifter eller glömt att fylla i obligatoriska uppgifter.
          this.buttonLink = ""
          this.errorText = "Please fill or correct fields."
        }
      }

    }

    //Här hämtas json-filen som innehåller info om rummen. Datat från filen lagras sedan i $scope-variabel med namnet rooms. 
    $http.get('js/rooms.json').success(function (response) {
      $scope.rooms = response;

      //Variabeln whichroom blir tilldelad ett värde från ett rummens namn/värde-par från JSON-filen. 
      $scope.whichroom = $state.params.roomId;
    })

  })


  .controller('myCtrl', function ($scope, $ionicHistory) {
    //ionicHistory håller koll på vilken sida som är den föregående, med andra cordova
    //vilken sida som ska visas när användaren trycker på tillbaka. 
    //Om appen består av olika tabs och flikar så håller den koll på vilken sida som är den föregående
    //inuti i den aktuella fliken.

    $scope.myGoBack = function () {
      $ionicHistory.goBack();
    }
  })



  .run(function ($ionicPlatform) {
    $ionicPlatform.ready(function () {
      if (window.cordova && window.cordova.plugins.Keyboard) {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

        // Don't remove this line unless you know what you are doing. It stops the viewport
        // from snapping when text inputs are focused. Ionic handles this internally for
        // a much nicer keyboard experience.
        cordova.plugins.Keyboard.disableScroll(true);
      }
      if (window.StatusBar) {
        StatusBar.styleDefault();
      }
    });
  })

